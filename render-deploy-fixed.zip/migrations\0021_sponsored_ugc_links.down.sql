ALTER TABLE `external_links` DROP COLUMN `sponsored`;
ALTER TABLE `external_links` DROP COLUMN `ugc`;