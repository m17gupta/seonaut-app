INSERT INTO issue_types (id, type, priority) VALUES(52, "ERROR_CONTENT_TYPE_OPTIONS", 3);
