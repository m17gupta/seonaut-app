package models

type Message struct {
	Name string
	Data interface{}
}
