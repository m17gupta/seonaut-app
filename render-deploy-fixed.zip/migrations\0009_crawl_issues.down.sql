ALTER TABLE `crawls` DROP COLUMN `notice_issues`;
ALTER TABLE `crawls` DROP COLUMN `warning_issues`;
ALTER TABLE `crawls` DROP COLUMN `critical_issues`;