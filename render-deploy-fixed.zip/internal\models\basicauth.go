package models

type BasicAuth struct {
	AuthUser string
	AuthPass string
}
