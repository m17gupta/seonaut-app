ALTER TABLE `pagereports` ADD COLUMN `robotstxt_blocked` tinyint NOT NULL DEFAULT '0';
