DELETE FROM issue_types WHERE id = 45;
DELETE FROM issue_types WHERE id = 46;
DELETE FROM issue_types WHERE id = 47;
DELETE FROM issue_types WHERE id = 48;