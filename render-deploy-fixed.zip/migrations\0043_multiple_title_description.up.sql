INSERT INTO issue_types (id, type, priority) VALUES(55, "ERROR_MULTIPLE_TITLES", 2);
INSERT INTO issue_types (id, type, priority) VALUES(56, "ERROR_MULTIPLE_DESCRIPTIONS", 2);