package models

type (
	ChartItem struct {
		Key   string
		Value int
	}

	Chart []ChartItem
)
