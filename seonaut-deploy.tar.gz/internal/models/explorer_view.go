package models

type ExplorerView struct {
	ProjectView   *ProjectView
	Term          string
	PaginatorView PaginatorView
}
