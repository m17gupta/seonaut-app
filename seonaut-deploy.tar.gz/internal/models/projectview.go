package models

type ProjectView struct {
	Project Project
	Crawl   Crawl
}
