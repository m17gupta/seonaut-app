package models

type Hreflang struct {
	URL  string
	Lang string
}
