package models

type Image struct {
	URL string
	Alt string
}
