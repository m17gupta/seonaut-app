package models

type PaginatorView struct {
	Paginator   Paginator
	PageReports []PageReport
}
