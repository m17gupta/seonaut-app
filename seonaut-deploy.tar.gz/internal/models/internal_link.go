package models

type InternalLink struct {
	PageReport PageReport
	Link       Link
}
