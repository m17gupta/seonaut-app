DELETE FROM issue_types WHERE id = 65;
DELETE FROM issue_types WHERE id = 66;