INSERT INTO issue_types (id, type, priority) VALUES(45, "ERROR_HREFLANG_XDEFAULT", 2);
INSERT INTO issue_types (id, type, priority) VALUES(46, "ERROR_HREFLANG_SELF_REFERENCE", 2);
INSERT INTO issue_types (id, type, priority) VALUES(47, "ERROR_HREFLANG_MISMATCHING_LANG", 2);
INSERT INTO issue_types (id, type, priority) VALUES(48, "ERROR_HREFLANG_RELATIVE_URL", 2);
