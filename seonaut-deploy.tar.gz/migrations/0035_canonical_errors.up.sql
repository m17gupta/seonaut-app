INSERT INTO issue_types (id, type, priority) VALUES(43, "ERROR_MULTIPLE_CANONICAL_TAGS", 2);
INSERT INTO issue_types (id, type, priority) VALUES(44, "ERROR_RELATIVE_CANONICAL_URL", 2);
