ALTER TABLE `crawls` DROP COLUMN `sitemap_exists`;
ALTER TABLE `crawls` DROP COLUMN `robotstxt_exists`;