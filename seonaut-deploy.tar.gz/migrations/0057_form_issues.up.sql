INSERT INTO issue_types (id, type, priority) VALUES(65, "ERROR_HTTP_FORM", 2);
INSERT INTO issue_types (id, type, priority) VALUES(66, "ERROR_INSECURE_FORM", 2);