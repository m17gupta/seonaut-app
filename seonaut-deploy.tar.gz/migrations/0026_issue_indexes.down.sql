drop index issues_type_report on issues;
drop index issue_type_priority on issue_types;