INSERT INTO issue_types (id, type, priority) VALUES(39, "ERROR_HREFLANG_REDIRECT", 2);
INSERT INTO issue_types (id, type, priority) VALUES(40, "ERROR_CANONICAL_REDIRECT", 2);
INSERT INTO issue_types (id, type, priority) VALUES(41, "ERROR_HREFLANG_ERROR", 2);
INSERT INTO issue_types (id, type, priority) VALUES(42, "ERROR_CANONICAL_ERROR", 2);