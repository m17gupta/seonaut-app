INSERT INTO issue_types (id, type, priority) VALUES(51, "ERROR_MISSING_CSP", 3);
