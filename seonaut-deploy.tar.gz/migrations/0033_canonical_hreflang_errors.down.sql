DELETE FROM issue_types WHERE id = 39;
DELETE FROM issue_types WHERE id = 40;
DELETE FROM issue_types WHERE id = 41;
DELETE FROM issue_types WHERE id = 42;