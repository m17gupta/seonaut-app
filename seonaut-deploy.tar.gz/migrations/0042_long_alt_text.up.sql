INSERT INTO issue_types (id, type, priority) VALUES(54, "ERROR_LONG_ALT_TEXT", 2);
