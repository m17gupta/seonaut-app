DROP INDEX links_crawl_nofollow ON links;
DROP INDEX external_crawl_nofollow ON external_links;