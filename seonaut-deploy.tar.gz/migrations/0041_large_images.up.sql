INSERT INTO issue_types (id, type, priority) VALUES(53, "ERROR_LARGE_IMAGE", 3);
