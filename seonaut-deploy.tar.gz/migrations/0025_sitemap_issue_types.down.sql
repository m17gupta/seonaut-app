DELETE FROM issue_types WHERE id = 31;
DELETE FROM issue_types WHERE id = 32;
DELETE FROM issue_types WHERE id = 33;