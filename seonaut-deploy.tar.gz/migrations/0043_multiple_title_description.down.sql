DELETE FROM issue_types WHERE id = 55;
DELETE FROM issue_types WHERE id = 56;