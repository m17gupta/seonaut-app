INSERT INTO issue_types (id, type, priority) VALUES(49, "ERROR_CANONICAL_MISMATCH", 2);
