ALTER TABLE `pagereports` ADD COLUMN `depth` int NOT NULL DEFAULT '0';
