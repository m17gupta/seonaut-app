DELETE FROM issue_types WHERE id = 43;
DELETE FROM issue_types WHERE id = 44;