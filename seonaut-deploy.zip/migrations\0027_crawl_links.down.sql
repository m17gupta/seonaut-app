ALTER TABLE `crawls` DROP COLUMN `links_internal_follow`;
ALTER TABLE `crawls` DROP COLUMN `links_internal_nofollow`;
ALTER TABLE `crawls` DROP COLUMN `links_external_follow`;
ALTER TABLE `crawls` DROP COLUMN `links_external_nofollow`;
ALTER TABLE `crawls` DROP COLUMN `links_sponsored`;
ALTER TABLE `crawls` DROP COLUMN `links_ugc`;