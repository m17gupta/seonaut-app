INSERT INTO issue_types (id, type, priority) VALUES(31, "NO_INDEX_IN_SITEMAP", 2);
INSERT INTO issue_types (id, type, priority) VALUES(32, "BLOCKED_IN_SITEMAP", 2);
INSERT INTO issue_types (id, type, priority) VALUES(33, "NON_CANONICAL_IN_SITEMAP", 2);