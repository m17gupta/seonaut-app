package models

type Video struct {
	URL    string
	Poster string
}
