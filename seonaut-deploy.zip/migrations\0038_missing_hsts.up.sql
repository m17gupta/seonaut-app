INSERT INTO issue_types (id, type, priority) VALUES(50, "ERROR_MISSING_HSTS", 3);
