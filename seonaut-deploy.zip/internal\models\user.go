package models

type User struct {
	Id       int
	Email    string
	Password string
}
