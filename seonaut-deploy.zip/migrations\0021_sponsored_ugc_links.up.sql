ALTER TABLE `external_links` ADD COLUMN `sponsored` tinyint NOT NULL DEFAULT '0';
ALTER TABLE `external_links` ADD COLUMN `ugc` tinyint NOT NULL DEFAULT '0';